package tcp.server.reply;

import java.io.PrintWriter;

public class VoidHandler implements IMessageHandler {

    public void handleMessage(String message, PrintWriter out) {
        
    }
}