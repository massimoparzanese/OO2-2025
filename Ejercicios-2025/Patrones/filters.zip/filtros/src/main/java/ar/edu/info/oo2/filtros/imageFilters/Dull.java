package ar.edu.info.oo2.filtros.imageFilters;

import java.awt.image.BufferedImage;

public class Dull extends Filter {
  
  
    
  public BufferedImage filter(BufferedImage image) {
    
    return image;
  }
}
